sudo docker stack deploy -c docker-compose.yml monitor
