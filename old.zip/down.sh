sudo docker stack remove monitor
