sudo docker stack remove monitor-gpu
