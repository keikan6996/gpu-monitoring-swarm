sudo docker stack deploy -c docker-compose-gpu.yml monitor-gpu
